import svgPaths from "./svg-1xcupnyvtf";
import img62A294D5D0Fd54502Ac58E15Credit20Card20MockupPng from "figma:asset/54668dc1dd1c9edf9753c15c1b1763a1a13352b2.png";
import img62A298520Cc803153Ade0C98Credit20Card20Mockup20WhitePng from "figma:asset/d53ab1a67e6695923bc380df8e888f8503df4d64.png";
import img62B9A942C0B6351858401716Screen01Png from "figma:asset/f22e22ba2d7ffcae05531355901b337a56d96438.png";
import img62A63Ca2Ce9Eb1059C7309E0Snippet201Jpg from "figma:asset/580862f56b61beeba1ee823c617b4365ba31f783.png";
import imgFrame from "figma:asset/7a20273b9518950bf932fd194e3a5d3a6ff72ab1.png";
import imgImage from "figma:asset/0be3546621a0c82f467a1065092444bbcf328c11.png";
import imgImage1 from "figma:asset/99025026ef545fce7a758188585b742e3d5aba25.png";
import imgImage2 from "figma:asset/2304ebd5cbe9ef3eb4df607005b8656e31a55b0e.png";
import imgImage3 from "figma:asset/b73f7d3f3f97b55b8691134f55142949dcc75229.png";
import img62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg from "figma:asset/711d215c09bbaf9831b812540d364b90252bfd1f.png";
import img62A0B8731B0B805Dada6D664Image2P500Jpeg from "figma:asset/5ddfd566bb2cdb5b6f0ed174696e7cf162ce9032.png";
import img62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg1 from "figma:asset/a1a08775dd49897427e368c58885a9e78e6e4481.png";
import img62A0B8731B0B805Dada6D664Image2P500Jpeg1 from "figma:asset/3f28053f0bce8492ac9cd971eb668d400ee8ff55.png";
import img62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg2 from "figma:asset/fe23390f9bb072f19aea58c16f066fb6a1da0b66.png";
import img62A0B8731B0B805Dada6D664Image2P500Jpeg2 from "figma:asset/d7782ac90c81a41ce9f2a97569e452e11b2e2e1f.png";
import img62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg3 from "figma:asset/10483042d606e630fb719f607537d1b88ee97d3c.png";
import img62A0B8731B0B805Dada6D664Image2P500Jpeg3 from "figma:asset/42ecea29e6da48d7cf7986754edad6a520cf49bc.png";

function Frame1618872240() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-[18px] items-center justify-start leading-[0] left-1/2 p-0 text-center text-nowrap top-32 translate-x-[-50%]">
      <div className="flex flex-col font-['Manrope:ExtraBold',_sans-serif] font-extrabold justify-center leading-[70px] relative shrink-0 text-[#202939] text-[56px] whitespace-pre">
        <p className="block mb-0">Manage Your Finances</p>
        <p className="block">Easier Than Ever</p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[28px] not-italic relative shrink-0 text-[#697586] text-[18px] whitespace-pre">
        <p className="block mb-0">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
        </p>
        <p className="block">
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare
        </p>
      </div>
    </div>
  );
}

function Link() {
  return (
    <div
      className="bg-[#202939] relative rounded-[32px] shrink-0"
      data-name="Link"
    >
      <div className="box-border content-stretch flex flex-col items-center justify-center overflow-clip px-[25px] py-3 relative">
        <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[16px] text-center text-nowrap">
          <p className="block leading-[24px] whitespace-pre">Get started</p>
        </div>
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#202939] border-solid inset-0 pointer-events-none rounded-[32px] shadow-[0px_4px_8px_-2px_rgba(0,0,0,0.1),0px_2px_4px_-2px_rgba(0,0,0,0.06)]"
      />
    </div>
  );
}

function Link1() {
  return (
    <div
      className="bg-[#ffffff] box-border content-stretch flex flex-col items-center justify-center px-6 py-3 relative rounded-[32px] shrink-0"
      data-name="Link"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Learn more</p>
      </div>
    </div>
  );
}

function DivButtonRow() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row gap-4 items-center justify-center left-[400px] px-[172px] py-0 top-[407px] w-[641px]"
      data-name="div.button-row"
    >
      <Link />
      <Link1 />
    </div>
  );
}

function DivHome1HeroActions() {
  return (
    <div
      className="absolute contents left-[400px] top-[407px]"
      data-name="div.home-1-hero-actions"
    >
      <DivButtonRow />
    </div>
  );
}

function Component62A294D5D0Fd54502Ac58E15Credit20Card20MockupPng() {
  return (
    <div
      className="absolute bg-no-repeat bg-size-[100%_100%] bg-top-left bottom-[-81.79px] top-[618.79px] translate-x-[-50%] w-[500px]"
      data-name="62a294d5d0fd54502ac58e15_Credit%20card%20mockup.png"
      style={{
        left: "calc(50% - 300px)",
        backgroundImage: `url('${img62A294D5D0Fd54502Ac58E15Credit20Card20MockupPng}')`,
      }}
    />
  );
}

function Component62A294D5D0Fd54502Ac58E15Credit20Card20MockupPng1() {
  return (
    <div
      className="absolute bg-no-repeat bg-size-[100%_100%] bg-top-left bottom-[-81.79px] top-[618.79px] translate-x-[-50%] w-[500px]"
      data-name="62a294d5d0fd54502ac58e15_Credit%20card%20mockup.png"
      style={{
        backgroundImage: `url('${img62A294D5D0Fd54502Ac58E15Credit20Card20MockupPng}')`,
        left: "calc(50% + 300px)",
      }}
    />
  );
}

function Component62A298520Cc803153Ade0C98Credit20Card20Mockup20WhitePng() {
  return (
    <div
      className="absolute bg-no-repeat bg-size-[100%_100%] bg-top-left bottom-[-58px] top-[558px] translate-x-[-50%] w-[562px]"
      data-name="62a298520cc803153ade0c98_Credit%20card%20mockup%20white.png"
      style={{
        left: "calc(50% - 7px)",
        backgroundImage: `url('${img62A298520Cc803153Ade0C98Credit20Card20Mockup20WhitePng}')`,
      }}
    />
  );
}

function Images() {
  return (
    <div
      className="absolute bottom-[-81.79px] contents left-1/2 top-[558px] translate-x-[-50%]"
      data-name="Images"
    >
      <Component62A294D5D0Fd54502Ac58E15Credit20Card20MockupPng />
      <Component62A294D5D0Fd54502Ac58E15Credit20Card20MockupPng1 />
      <Component62A298520Cc803153Ade0C98Credit20Card20Mockup20WhitePng />
    </div>
  );
}

function Header() {
  return (
    <div
      className="absolute bottom-[-92px] left-0.5 overflow-clip right-[-2px] top-[174px]"
      data-name="Header"
    >
      <Frame1618872240 />
      <DivHome1HeroActions />
      <div
        className="absolute bg-[#84caff] blur-[26.9px] bottom-[-380px] filter rounded-[720px] top-[497px] translate-x-[-50%] w-[720px]"
        data-name="div.circle-primary"
        style={{ left: "calc(50% - 260px)" }}
      />
      <div
        className="absolute bg-[rgba(234,85,237,0.8)] blur-[26.9px] bottom-[-380px] filter rounded-[720px] top-[497px] translate-x-[-50%] w-[720px]"
        data-name="div.circle-pink"
        style={{ left: "calc(50% + 260px)" }}
      />
      <Images />
    </div>
  );
}

function Component6298D6950F795E3C29526106BrandSvg() {
  return (
    <div
      className="h-[34px] relative shrink-0 w-[138px]"
      data-name="6298d6950f795e3c29526106_Brand.svg"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 138 34"
      >
        <g id="6298d6950f795e3c29526106_Brand.svg">
          <path
            d={svgPaths.p34faab00}
            fill="var(--fill-0, #BA24D5)"
            id="Vector"
          />
          <path
            d={svgPaths.p4123480}
            fill="var(--fill-0, #202939)"
            id="Vector_2"
          />
        </g>
      </svg>
    </div>
  );
}

function Component6298D6950F795E3C29526106BrandSvgFill() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[34px] items-center justify-center overflow-clip p-0 relative shrink-0 w-[138px]"
      data-name="6298d6950f795e3c29526106_Brand.svg fill"
    >
      <Component6298D6950F795E3C29526106BrandSvg />
    </div>
  );
}

function Link6298D6950F795E3C29526106BrandSvg() {
  return (
    <a
      className="absolute box-border content-stretch cursor-pointer flex flex-row items-center justify-start left-20 max-w-[138px] overflow-clip p-0 top-1/2 translate-y-[-50%]"
      data-name="Link → 6298d6950f795e3c29526106_Brand.svg"
      href="https://financiotemplate.webflow.io/home/home-v1"
    >
      <Component6298D6950F795E3C29526106BrandSvgFill />
    </a>
  );
}

function ArrowDown01() {
  return (
    <div className="relative shrink-0 size-4" data-name="arrow-down-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-down-01">
          <path
            d="M4 6.00003L8 10L12 6"
            id="Vector"
            stroke="var(--stroke-0, #697586)"
            strokeMiterlimit="16"
            strokeWidth="1.5"
          />
        </g>
      </svg>
    </div>
  );
}

function Div() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-1 h-[25px] items-center justify-start p-0 relative shrink-0"
      data-name="div"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Pages</p>
      </div>
      <ArrowDown01 />
    </div>
  );
}

function Frame1618872257() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-10 items-center justify-start left-1/2 p-0 top-7 translate-x-[-50%]">
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Home</p>
      </div>
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Company</p>
      </div>
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Blog</p>
      </div>
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Pricing</p>
      </div>
      <Div />
    </div>
  );
}

function Link2() {
  return (
    <div
      className="absolute bg-[#202939] left-[1229px] rounded-[32px] top-1/2 translate-y-[-50%]"
      data-name="Link"
    >
      <div className="box-border content-stretch flex flex-col items-center justify-center overflow-clip px-5 py-2 relative">
        <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[16px] text-center text-nowrap">
          <p className="block leading-[24px] whitespace-pre">Get started</p>
        </div>
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#202939] border-solid inset-0 pointer-events-none rounded-[32px] shadow-[0px_4px_8px_-2px_rgba(0,0,0,0.1),0px_2px_4px_-2px_rgba(0,0,0,0.06)]"
      />
    </div>
  );
}

function TopBar() {
  return (
    <div className="absolute h-[82px] left-0 right-0 top-0" data-name="Top bar">
      <Link6298D6950F795E3C29526106BrandSvg />
      <Frame1618872257 />
      <Link2 />
    </div>
  );
}

function Section10() {
  return (
    <div
      className="absolute h-[919px] left-0 overflow-clip right-0 top-0"
      data-name="Section 10"
    >
      <Header />
      <TopBar />
    </div>
  );
}

function Frame1618872244() {
  return (
    <div className="box-border content-stretch flex flex-col gap-6 items-center justify-start leading-[0] p-0 relative shrink-0 text-center">
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center relative shrink-0 text-[#202939] text-[40px] w-[650px]">
        <p className="block leading-[48px]">
          In partnership with the top fintech companies
        </p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[28px] not-italic relative shrink-0 text-[#697586] text-[18px] text-nowrap whitespace-pre">
        <p className="block mb-0">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in
        </p>
        <p className="block mb-0">
          eros elementum tristique. Duis cursus, mi quis viverra ornare, eros
          dolor interdum
        </p>
        <p className="block">nulla, ut commodo diam libero vitae erat.</p>
      </div>
    </div>
  );
}

function Component6299390D51673272762068E201Svg() {
  return (
    <div
      className="h-[31px] relative shrink-0 w-[158px]"
      data-name="6299390d51673272762068e2_01.svg"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 158 31"
      >
        <g id="6299390d51673272762068e2_01.svg">
          <path
            d="M17 3L13 27"
            id="Vector"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M17 8L12 22"
            id="Vector_2"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M17 12L13 19"
            id="Vector_3"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M23 6L6 26"
            id="Vector_4"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M17 13L12 17"
            id="Vector_5"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M20 14L10 18"
            id="Vector_6"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M28 16H2"
            id="Vector_7"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M25 18L4 14"
            id="Vector_8"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M26 20L4 12"
            id="Vector_9"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M18 17L11 13"
            id="Vector_10"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M23 22L6 8"
            id="Vector_11"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M19 20L11 11"
            id="Vector_12"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M18 25L11 6"
            id="Vector_13"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M15 18L14 13"
            id="Vector_14"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M15 21V10"
            id="Vector_15"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M13 27L17 5"
            id="Vector_16"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M14 18L16 14"
            id="Vector_17"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M11 19L18 11"
            id="Vector_18"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M11 18L18 12"
            id="Vector_19"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M3 22L26 9"
            id="Vector_20"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M3 17L27 13"
            id="Vector_21"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M6 16H23"
            id="Vector_22"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M2 8L27 22"
            id="Vector_23"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M11 13L18 19"
            id="Vector_24"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M13 13L16 17"
            id="Vector_25"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M9 6L20 25"
            id="Vector_26"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M15 3V29"
            id="Vector_27"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M15 14L14 18"
            id="Vector_28"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M27 8L2 22"
            id="Vector_29"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d="M20 16H10"
            id="Vector_30"
            stroke="var(--stroke-0, #697586)"
            strokeLinecap="square"
            strokeWidth="2"
          />
          <path
            d={svgPaths.p1a7c8c00}
            fill="var(--fill-0, #697586)"
            id="Vector_31"
          />
          <path
            d={svgPaths.p36f15880}
            fill="var(--fill-0, #697586)"
            id="Vector_32"
          />
          <path
            d={svgPaths.pf517700}
            fill="var(--fill-0, #697586)"
            id="Vector_33"
          />
          <path
            d={svgPaths.p2d6de600}
            fill="var(--fill-0, #697586)"
            id="Vector_34"
          />
          <path
            d={svgPaths.p16f51700}
            fill="var(--fill-0, #697586)"
            id="Vector_35"
          />
          <path
            d={svgPaths.p3262c480}
            fill="var(--fill-0, #697586)"
            id="Vector_36"
          />
          <path
            d={svgPaths.p12f61080}
            fill="var(--fill-0, #697586)"
            id="Vector_37"
          />
          <path
            d={svgPaths.p32812e00}
            fill="var(--fill-0, #697586)"
            id="Vector_38"
          />
          <path
            d={svgPaths.p5e9b200}
            fill="var(--fill-0, #697586)"
            id="Vector_39"
          />
        </g>
      </svg>
    </div>
  );
}

function Component6299390D51673272762068E201SvgFill() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[31px] items-center justify-center overflow-clip p-0 relative shrink-0 w-[158px]"
      data-name="6299390d51673272762068e2_01.svg fill"
    >
      <Component6299390D51673272762068E201Svg />
    </div>
  );
}

function Component6299390D51673272762068E201Svg1() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-center max-h-14 max-w-[768px] overflow-clip p-0 relative shrink-0"
      data-name="6299390d51673272762068e2_01.svg"
    >
      <Component6299390D51673272762068E201SvgFill />
    </div>
  );
}

function Component6299390C1C094498950604A203Svg() {
  return (
    <div
      className="h-[31px] relative shrink-0 w-[150px]"
      data-name="6299390c1c094498950604a2_03.svg"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 150 31"
      >
        <g id="6299390c1c094498950604a2_03.svg">
          <path d="M1 1H16L1 16V1Z" fill="var(--fill-0, #697586)" id="Vector" />
          <path
            d="M16.0001 16H1V31H16.0001V16Z"
            fill="var(--fill-0, #697586)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p14e97b00}
            fill="var(--fill-0, #697586)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p38a38280}
            fill="var(--fill-0, #697586)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p1e889f00}
            fill="var(--fill-0, #697586)"
            id="Vector_5"
          />
          <path
            d={svgPaths.p2ecced80}
            fill="var(--fill-0, #697586)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p2a2b4f00}
            fill="var(--fill-0, #697586)"
            id="Vector_7"
          />
          <path
            d={svgPaths.p719c1f0}
            fill="var(--fill-0, #697586)"
            id="Vector_8"
          />
          <path
            d={svgPaths.p6a90ff0}
            fill="var(--fill-0, #697586)"
            id="Vector_9"
          />
          <path
            d={svgPaths.p1c62ea00}
            fill="var(--fill-0, #697586)"
            id="Vector_10"
          />
          <path
            d={svgPaths.p34b6a700}
            fill="var(--fill-0, #697586)"
            id="Vector_11"
          />
          <path
            d="M16 1H31L16 16V1Z"
            fill="var(--fill-0, #697586)"
            id="Vector_12"
          />
          <path
            d="M16 16H31L16 31V16Z"
            fill="var(--fill-0, #697586)"
            id="Vector_13"
          />
          <path
            d={svgPaths.p14e97b00}
            fill="var(--fill-0, #697586)"
            id="Vector_14"
          />
          <path
            d={svgPaths.p38a38280}
            fill="var(--fill-0, #697586)"
            id="Vector_15"
          />
          <path
            d={svgPaths.p1e889f00}
            fill="var(--fill-0, #697586)"
            id="Vector_16"
          />
          <path
            d={svgPaths.p2ecced80}
            fill="var(--fill-0, #697586)"
            id="Vector_17"
          />
          <path
            d={svgPaths.p2a2b4f00}
            fill="var(--fill-0, #697586)"
            id="Vector_18"
          />
          <path
            d={svgPaths.p719c1f0}
            fill="var(--fill-0, #697586)"
            id="Vector_19"
          />
          <path
            d={svgPaths.p6a90ff0}
            fill="var(--fill-0, #697586)"
            id="Vector_20"
          />
          <path
            d={svgPaths.p1c62ea00}
            fill="var(--fill-0, #697586)"
            id="Vector_21"
          />
          <path
            d={svgPaths.p34b6a700}
            fill="var(--fill-0, #697586)"
            id="Vector_22"
          />
        </g>
      </svg>
    </div>
  );
}

function Component6299390C1C094498950604A203SvgFill() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[31px] items-center justify-center overflow-clip p-0 relative shrink-0 w-[150px]"
      data-name="6299390c1c094498950604a2_03.svg fill"
    >
      <Component6299390C1C094498950604A203Svg />
    </div>
  );
}

function Component6299390C1C094498950604A203Svg1() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-center max-h-14 max-w-[768px] overflow-clip p-0 relative shrink-0"
      data-name="6299390c1c094498950604a2_03.svg"
    >
      <Component6299390C1C094498950604A203SvgFill />
    </div>
  );
}

function Component6299394E2D17093Ce710E4F908Svg() {
  return (
    <div
      className="h-[31px] relative shrink-0 w-[138px]"
      data-name="6299394e2d17093ce710e4f9_08.svg"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 138 31"
      >
        <g clipPath="url(#clip0_1_587)" id="6299394e2d17093ce710e4f9_08.svg">
          <path
            d={svgPaths.p1c0fdb00}
            fill="var(--fill-0, #697586)"
            id="Vector"
          />
          <path
            d={svgPaths.p23234500}
            fill="var(--fill-0, #697586)"
            id="Vector_2"
          />
          <path
            d="M33 7H36V22H33V7Z"
            fill="var(--fill-0, #697586)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p26695c00}
            fill="var(--fill-0, #697586)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p9a4b380}
            fill="var(--fill-0, #697586)"
            id="Vector_5"
          />
          <path
            d={svgPaths.p35d04c00}
            fill="var(--fill-0, #697586)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p3e397a00}
            fill="var(--fill-0, #697586)"
            id="Vector_7"
          />
          <path
            d={svgPaths.p3638ef00}
            fill="var(--fill-0, #697586)"
            id="Vector_8"
          />
          <path
            d={svgPaths.p9228c00}
            fill="var(--fill-0, #697586)"
            id="Vector_9"
          />
          <path
            d={svgPaths.p16edf100}
            fill="var(--fill-0, #697586)"
            id="Vector_10"
          />
          <path
            d={svgPaths.p102b5400}
            fill="var(--fill-0, #697586)"
            id="Vector_11"
          />
          <path
            d={svgPaths.p91d3300}
            fill="var(--fill-0, #697586)"
            id="Vector_12"
          />
        </g>
        <defs>
          <clipPath id="clip0_1_587">
            <rect fill="white" height="31" width="138" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Component6299394E2D17093Ce710E4F908SvgFill() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[31px] items-center justify-center overflow-clip p-0 relative shrink-0 w-[138px]"
      data-name="6299394e2d17093ce710e4f9_08.svg fill"
    >
      <Component6299394E2D17093Ce710E4F908Svg />
    </div>
  );
}

function Component6299394E2D17093Ce710E4F908Svg1() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-center max-h-14 max-w-[768px] overflow-clip p-0 relative shrink-0"
      data-name="6299394e2d17093ce710e4f9_08.svg"
    >
      <Component6299394E2D17093Ce710E4F908SvgFill />
    </div>
  );
}

function Frame1618872243() {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-start justify-start p-0 relative shrink-0">
      <Component6299390D51673272762068E201Svg1 />
      <Component6299390C1C094498950604A203Svg1 />
      <Component6299394E2D17093Ce710E4F908Svg1 />
    </div>
  );
}

function Frame1618872245() {
  return (
    <div className="box-border content-stretch flex flex-col gap-8 items-center justify-start p-0 relative shrink-0">
      <Frame1618872244 />
      <Frame1618872243 />
    </div>
  );
}

function Link3() {
  return (
    <div
      className="bg-[#ffffff] box-border content-stretch flex flex-col items-center justify-center px-[25px] py-3 relative rounded-[32px] shrink-0"
      data-name="Link"
    >
      <div
        aria-hidden="true"
        className="absolute border border-[#364152] border-solid inset-0 pointer-events-none rounded-[32px]"
      />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Get started</p>
      </div>
    </div>
  );
}

function Div1() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[17px] items-center justify-start pb-[0.5px] pt-0 px-0 relative shrink-0"
      data-name="div"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-center text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Learn more</p>
      </div>
    </div>
  );
}

function ArrowDown2() {
  return (
    <div className="relative size-4" data-name="arrow-down-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-down-01">
          <path
            d="M4 6.00003L8 10L12 6"
            id="Vector"
            stroke="var(--stroke-0, #364152)"
            strokeMiterlimit="16"
            strokeWidth="1.5"
          />
        </g>
      </svg>
    </div>
  );
}

function Link4() {
  return (
    <a
      className="box-border content-stretch cursor-pointer flex flex-row gap-2 items-center justify-start max-w-[768px] overflow-visible px-0 py-1 relative shrink-0"
      data-name="Link"
      href="https://financiotemplate.webflow.io/pricing"
    >
      <Div1 />
      <div className="flex h-[15.984px] items-center justify-center relative shrink-0 w-[15.984px]">
        <div className="flex-none rotate-[270deg]">
          <ArrowDown2 />
        </div>
      </div>
    </a>
  );
}

function Frame1618872247() {
  return (
    <div className="box-border content-stretch flex flex-row gap-6 items-center justify-start p-0 relative shrink-0">
      <Link3 />
      <Link4 />
    </div>
  );
}

function Frame1618872248() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-col gap-11 items-center justify-start p-0 top-[120px] translate-x-[-50%]"
      style={{ left: "calc(50% + 0.5px)" }}
    >
      <Frame1618872245 />
      <Frame1618872247 />
    </div>
  );
}

function Section09() {
  return (
    <div
      className="absolute h-[599px] left-0 top-[919px] w-[1440px]"
      data-name="Section 09"
    >
      <Frame1618872248 />
    </div>
  );
}

function DivTagline() {
  return (
    <div
      className="bg-[#ebeff5] box-border content-stretch flex flex-row items-center justify-center px-3 py-1 relative rounded-3xl shrink-0"
      data-name="div.tagline"
    >
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[15px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Smooth onboarding</p>
      </div>
    </div>
  );
}

function CheckmarkCircle01() {
  return (
    <div className="relative shrink-0 size-6" data-name="checkmark-circle-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="checkmark-circle-01">
          <path
            clipRule="evenodd"
            d={svgPaths.p6d3dc00}
            fill="var(--fill-0, #BA24D5)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872267() {
  return (
    <div className="box-border content-stretch flex flex-row gap-3 items-start justify-start p-0 relative shrink-0">
      <CheckmarkCircle01 />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[18px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Saving</p>
      </div>
    </div>
  );
}

function CheckmarkCircle2() {
  return (
    <div className="relative shrink-0 size-6" data-name="checkmark-circle-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="checkmark-circle-01">
          <path
            clipRule="evenodd"
            d={svgPaths.p6d3dc00}
            fill="var(--fill-0, #BA24D5)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872268() {
  return (
    <div className="box-border content-stretch flex flex-row gap-3 items-center justify-start p-0 relative shrink-0">
      <CheckmarkCircle2 />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[18px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Investing</p>
      </div>
    </div>
  );
}

function CheckmarkCircle3() {
  return (
    <div className="relative shrink-0 size-6" data-name="checkmark-circle-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="checkmark-circle-01">
          <path
            clipRule="evenodd"
            d={svgPaths.p6d3dc00}
            fill="var(--fill-0, #BA24D5)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872269() {
  return (
    <div className="box-border content-stretch flex flex-row gap-3 items-center justify-start p-0 relative shrink-0">
      <CheckmarkCircle3 />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[18px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Tracking</p>
      </div>
    </div>
  );
}

function Frame1618872270() {
  return (
    <div className="box-border content-stretch flex flex-col gap-3 items-start justify-start p-0 relative shrink-0">
      <Frame1618872267 />
      <Frame1618872268 />
      <Frame1618872269 />
    </div>
  );
}

function CheckmarkCircle4() {
  return (
    <div className="relative shrink-0 size-6" data-name="checkmark-circle-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="checkmark-circle-01">
          <path
            clipRule="evenodd"
            d={svgPaths.p6d3dc00}
            fill="var(--fill-0, #BA24D5)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872272() {
  return (
    <div className="box-border content-stretch flex flex-row gap-3 items-center justify-start p-0 relative shrink-0">
      <CheckmarkCircle4 />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[18px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Payments</p>
      </div>
    </div>
  );
}

function CheckmarkCircle5() {
  return (
    <div className="relative shrink-0 size-6" data-name="checkmark-circle-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="checkmark-circle-01">
          <path
            clipRule="evenodd"
            d={svgPaths.p6d3dc00}
            fill="var(--fill-0, #BA24D5)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872271() {
  return (
    <div className="box-border content-stretch flex flex-row gap-3 items-center justify-start p-0 relative shrink-0">
      <CheckmarkCircle5 />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[18px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Scheduling</p>
      </div>
    </div>
  );
}

function Frame1618872273() {
  return (
    <div className="box-border content-stretch flex flex-col gap-3 items-start justify-start p-0 relative shrink-0">
      <Frame1618872272 />
      <Frame1618872271 />
    </div>
  );
}

function Frame1618872280() {
  return (
    <div className="box-border content-stretch flex flex-row gap-[60px] items-start justify-start p-0 relative shrink-0">
      <Frame1618872270 />
      <Frame1618872273 />
    </div>
  );
}

function Frame1618872281() {
  return (
    <div className="box-border content-stretch flex flex-col gap-8 items-start justify-start p-0 relative shrink-0">
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap whitespace-pre">
        <p className="block mb-0">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
        </p>
        <p className="block">varius enim in eros elementum tristique.</p>
      </div>
      <Frame1618872280 />
    </div>
  );
}

function Frame1618872282() {
  return (
    <div className="box-border content-stretch flex flex-col gap-5 items-start justify-start p-0 relative shrink-0">
      <DivTagline />
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#202939] text-[40px] text-left w-[483px]">
        <p className="block leading-[48px]">
          Your personal finances, a few taps away.
        </p>
      </div>
      <Frame1618872281 />
    </div>
  );
}

function Link5() {
  return (
    <div
      className="bg-[#ffffff] box-border content-stretch flex flex-col items-center justify-center px-[25px] py-3 relative rounded-[32px] shrink-0"
      data-name="Link"
    >
      <div
        aria-hidden="true"
        className="absolute border border-[#364152] border-solid inset-0 pointer-events-none rounded-[32px]"
      />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Get started</p>
      </div>
    </div>
  );
}

function ArrowDown3() {
  return (
    <div className="relative size-4" data-name="arrow-down-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-down-01">
          <path
            d="M4 6.00003L8 10L12 6"
            id="Vector"
            stroke="var(--stroke-0, #364152)"
            strokeMiterlimit="16"
            strokeWidth="1.5"
          />
        </g>
      </svg>
    </div>
  );
}

function Div2() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="div"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Learn more</p>
      </div>
      <div className="flex h-[15.984px] items-center justify-center relative shrink-0 w-[15.984px]">
        <div className="flex-none rotate-[270deg]">
          <ArrowDown3 />
        </div>
      </div>
    </div>
  );
}

function Frame1618872279() {
  return (
    <div className="box-border content-stretch flex flex-row gap-4 items-center justify-start p-0 relative shrink-0">
      <Link5 />
      <Div2 />
    </div>
  );
}

function Frame1618872285() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-10 items-start justify-start left-20 p-0 top-[100px]">
      <Frame1618872282 />
      <Frame1618872279 />
    </div>
  );
}

function Component62B9A942C0B6351858401716Screen01Png() {
  return (
    <div
      className="absolute bg-[50.04%_0%] bg-no-repeat bg-size-[100%_100.47%] bottom-[120px] top-5 translate-x-[-50%] w-[392px]"
      data-name="62b9a942c0b6351858401716_screen-01.png"
      style={{
        left: "calc(50% + 352px)",
        backgroundImage: `url('${img62B9A942C0B6351858401716Screen01Png}')`,
      }}
    />
  );
}

function Component62A63Ca2Ce9Eb1059C7309E0Snippet201Jpg() {
  return (
    <div
      className="basis-0 bg-no-repeat bg-size-[100%_100%] bg-top-left grow min-h-px min-w-px shrink-0 w-full"
      data-name="62a63ca2ce9eb1059c7309e0_Snippet%201.jpg"
      style={{
        backgroundImage: `url('${img62A63Ca2Ce9Eb1059C7309E0Snippet201Jpg}')`,
      }}
    />
  );
}

function DivFeature1InfoCard() {
  return (
    <div
      className="absolute bg-[#ffffff] box-border content-stretch flex flex-col h-[280px] items-start justify-center left-[812px] overflow-clip p-0 rounded-2xl shadow-[0px_8px_8px_-4px_rgba(16,24,40,0.03),0px_20px_24px_-4px_rgba(16,24,40,0.08)] top-[316px] w-[230px]"
      data-name="div.feature-1-info-card"
    >
      <Component62A63Ca2Ce9Eb1059C7309E0Snippet201Jpg />
    </div>
  );
}

function DivFeature1InfoCardWrapper() {
  return (
    <div
      className="absolute contents left-[812px] top-[316px]"
      data-name="div.feature-1-info-card-wrapper"
    >
      <DivFeature1InfoCard />
    </div>
  );
}

function Section08() {
  return (
    <div
      className="absolute bg-[#ffffff] h-[777px] left-0 right-0 top-[1518px]"
      data-name="Section 08"
    >
      <Frame1618872285 />
      <Component62B9A942C0B6351858401716Screen01Png />
      <DivFeature1InfoCardWrapper />
    </div>
  );
}

function Component62B9A942C0B6351858401716Screen01Png1() {
  return (
    <div
      className="absolute bg-[50.04%_0%] bg-no-repeat bg-size-[100%_100%] bottom-0 top-32 translate-x-[-50%] w-[392px]"
      data-name="62b9a942c0b6351858401716_screen-01.png"
      style={{
        left: "calc(50% - 352px)",
        backgroundImage: `url('${img62B9A942C0B6351858401716Screen01Png}')`,
      }}
    />
  );
}

function Frame() {
  return (
    <div
      className="bg-no-repeat bg-size-[100%_100%] bg-top-left h-full shrink-0 w-[324px]"
      data-name="frame"
      style={{ backgroundImage: `url('${imgFrame}')` }}
    />
  );
}

function DivFeature2NotificationWrapper() {
  return (
    <div
      className="absolute bottom-[20.05%] box-border content-stretch flex flex-row items-center justify-center p-0 top-[67.97%] translate-x-[-50%]"
      data-name="div.feature-2-notification-wrapper"
      style={{ left: "calc(50% - 478px)" }}
    >
      <Frame />
    </div>
  );
}

function DivTagline1() {
  return (
    <div
      className="bg-[#ebeff5] box-border content-stretch flex flex-row items-center justify-center px-3 py-1 relative rounded-3xl shrink-0"
      data-name="div.tagline"
    >
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[15px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Notifications</p>
      </div>
    </div>
  );
}

function MagicWand01() {
  return (
    <div className="relative shrink-0 size-8" data-name="magic-wand-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 32 32"
      >
        <g id="magic-wand-01">
          <path
            d={svgPaths.p289a8980}
            id="Vector"
            stroke="var(--stroke-0, #039855)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
          <path
            d={svgPaths.p21b09400}
            id="Vector_2"
            stroke="var(--stroke-0, #039855)"
            strokeLinejoin="round"
            strokeWidth="2"
          />
          <path
            d={svgPaths.p1cc1c200}
            id="Vector_3"
            stroke="var(--stroke-0, #039855)"
            strokeLinejoin="round"
            strokeWidth="2"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872315() {
  return (
    <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0">
      <MagicWand01 />
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#039855] text-[14px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Up to 25%</p>
      </div>
    </div>
  );
}

function DivFeatureBadge() {
  return (
    <div
      className="absolute bg-[#ecfdf3] box-border content-stretch flex flex-row gap-1.5 items-center justify-start left-[119px] px-2 py-1 rounded-3xl top-1/2 translate-y-[-50%]"
      data-name="div.feature-badge"
    >
      <Frame1618872315 />
    </div>
  );
}

function DivTextWrapperHeading() {
  return (
    <div
      className="h-[49px] relative shrink-0 w-full"
      data-name="div.text-wrapper-heading"
    >
      <div className="absolute flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] left-0 text-[#202939] text-[40px] text-left text-nowrap top-6 translate-y-[-50%]">
        <p className="block leading-[48px] whitespace-pre">$129</p>
      </div>
      <DivFeatureBadge />
    </div>
  );
}

function DivFeature2TextWrapper() {
  return (
    <div
      className="bg-[#ffffff] box-border content-stretch flex flex-col gap-2 items-start justify-start overflow-clip px-4 py-6 relative rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)] shrink-0 w-[276px]"
      data-name="div.feature-2-text-wrapper"
    >
      <DivTextWrapperHeading />
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[21px] not-italic relative shrink-0 text-[#697586] text-[14px] text-left text-nowrap whitespace-pre">
        <p className="block mb-0">Lorem ipsum dolor sit amet,</p>
        <p className="block">consectetur adipiscing elit.</p>
      </div>
    </div>
  );
}

function MagicWand2() {
  return (
    <div className="relative shrink-0 size-8" data-name="magic-wand-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 32 32"
      >
        <g id="magic-wand-01">
          <path
            d={svgPaths.p289a8980}
            id="Vector"
            stroke="var(--stroke-0, #039855)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
          <path
            d={svgPaths.p21b09400}
            id="Vector_2"
            stroke="var(--stroke-0, #039855)"
            strokeLinejoin="round"
            strokeWidth="2"
          />
          <path
            d={svgPaths.p1cc1c200}
            id="Vector_3"
            stroke="var(--stroke-0, #039855)"
            strokeLinejoin="round"
            strokeWidth="2"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872314() {
  return (
    <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0">
      <MagicWand2 />
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#039855] text-[14px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Up to 25%</p>
      </div>
    </div>
  );
}

function DivFeatureBadge1() {
  return (
    <div
      className="absolute bg-[#ecfdf3] box-border content-stretch flex flex-row gap-1.5 items-center justify-start left-[115px] px-2 py-1 rounded-3xl top-1/2 translate-y-[-50%]"
      data-name="div.feature-badge"
    >
      <Frame1618872314 />
    </div>
  );
}

function DivTextWrapperHeading1() {
  return (
    <div
      className="h-[49px] relative shrink-0 w-full"
      data-name="div.text-wrapper-heading"
    >
      <div className="absolute flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] left-0 text-[#202939] text-[40px] text-left text-nowrap top-6 translate-y-[-50%]">
        <p className="block leading-[48px] whitespace-pre">$229</p>
      </div>
      <DivFeatureBadge1 />
    </div>
  );
}

function DivFeature2TextWrapper1() {
  return (
    <div
      className="bg-[#ffffff] box-border content-stretch flex flex-col gap-2 items-start justify-start overflow-clip px-4 py-6 relative rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)] shrink-0 w-[276px]"
      data-name="div.feature-2-text-wrapper"
    >
      <DivTextWrapperHeading1 />
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[21px] not-italic relative shrink-0 text-[#697586] text-[14px] text-left text-nowrap whitespace-pre">
        <p className="block mb-0">Lorem ipsum dolor sit amet,</p>
        <p className="block">consectetur adipiscing elit.</p>
      </div>
    </div>
  );
}

function Frame1618872300() {
  return (
    <div className="box-border content-stretch flex flex-row gap-6 items-start justify-start p-0 relative shrink-0">
      <DivFeature2TextWrapper />
      <DivFeature2TextWrapper1 />
    </div>
  );
}

function Frame1618872321() {
  return (
    <div className="box-border content-stretch flex flex-col gap-8 items-start justify-start p-0 relative shrink-0">
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap whitespace-pre">
        <p className="block mb-0">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
        </p>
        <p className="block">varius enim in eros elementum tristique.</p>
      </div>
      <Frame1618872300 />
    </div>
  );
}

function Frame1618872322() {
  return (
    <div className="box-border content-stretch flex flex-col gap-5 items-start justify-start p-0 relative shrink-0">
      <DivTagline1 />
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[48px] relative shrink-0 text-[#202939] text-[40px] text-left text-nowrap whitespace-pre">
        <p className="block mb-0">Real time notifications on</p>
        <p className="block">account activity</p>
      </div>
      <Frame1618872321 />
    </div>
  );
}

function Link6() {
  return (
    <div
      className="bg-[#ffffff] box-border content-stretch flex flex-col items-center justify-center px-[25px] py-3 relative rounded-[32px] shrink-0"
      data-name="Link"
    >
      <div
        aria-hidden="true"
        className="absolute border border-[#364152] border-solid inset-0 pointer-events-none rounded-[32px]"
      />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Get started</p>
      </div>
    </div>
  );
}

function ArrowDown4() {
  return (
    <div className="relative size-4" data-name="arrow-down-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-down-01">
          <path
            d="M4 6.00003L8 10L12 6"
            id="Vector"
            stroke="var(--stroke-0, #364152)"
            strokeMiterlimit="16"
            strokeWidth="1.5"
          />
        </g>
      </svg>
    </div>
  );
}

function Div3() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="div"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Learn more</p>
      </div>
      <div className="flex h-[15.984px] items-center justify-center relative shrink-0 w-[15.984px]">
        <div className="flex-none rotate-[270deg]">
          <ArrowDown4 />
        </div>
      </div>
    </div>
  );
}

function Frame1618872283() {
  return (
    <div className="box-border content-stretch flex flex-row gap-4 items-center justify-start p-0 relative shrink-0">
      <Link6 />
      <Div3 />
    </div>
  );
}

function Frame1618872325() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-10 items-start justify-start left-[784px] p-0 top-[120px]">
      <Frame1618872322 />
      <Frame1618872283 />
    </div>
  );
}

function Section07() {
  return (
    <div
      className="absolute bg-[#f6f6f6] h-[768px] left-0 overflow-clip right-0 top-[2295px]"
      data-name="Section 07"
    >
      <Component62B9A942C0B6351858401716Screen01Png1 />
      <DivFeature2NotificationWrapper />
      <Frame1618872325 />
    </div>
  );
}

function PaymentSuccess02() {
  return (
    <div
      className="absolute left-2.5 size-7 top-2.5"
      data-name="payment-success-02"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 28 28"
      >
        <g id="payment-success-02">
          <path
            clipRule="evenodd"
            d={svgPaths.p12a33040}
            fill="var(--fill-0, #BA24D5)"
            fillRule="evenodd"
            id="Vector"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.pc89c400}
            fill="var(--fill-0, #BA24D5)"
            fillRule="evenodd"
            id="Vector_2"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1() {
  return (
    <div
      className="bg-[#fbe8ff] relative rounded-[48px] shrink-0 size-12"
      data-name="frame"
    >
      <PaymentSuccess02 />
    </div>
  );
}

function Frame1618872371() {
  return (
    <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start leading-[0] p-0 relative shrink-0 text-left text-nowrap">
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center relative shrink-0 text-[#202939] text-[24px]">
        <p className="block leading-[32px] text-nowrap whitespace-pre">
          Streamlined payments
        </p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[#697586] text-[16px] whitespace-pre">
        <p className="block mb-0">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        </p>
        <p className="block">
          Suspendisse varius enim in eros elementum tristique.
        </p>
      </div>
    </div>
  );
}

function Frame1618872378() {
  return (
    <div className="box-border content-stretch flex flex-row gap-6 items-start justify-start p-0 relative shrink-0">
      <Frame1 />
      <Frame1618872371 />
    </div>
  );
}

function PiggyBank() {
  return (
    <div className="absolute left-2.5 size-7 top-2.5" data-name="piggy-bank">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 28 28"
      >
        <g id="piggy-bank">
          <path
            clipRule="evenodd"
            d={svgPaths.pa98ae80}
            fill="var(--fill-0, #BA24D5)"
            fillRule="evenodd"
            id="Vector"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p201b4000}
            fill="var(--fill-0, #BA24D5)"
            fillRule="evenodd"
            id="Vector_2"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame2() {
  return (
    <div
      className="bg-[#fbe8ff] relative rounded-[48px] shrink-0 size-12"
      data-name="frame"
    >
      <PiggyBank />
    </div>
  );
}

function Frame1618872372() {
  return (
    <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start leading-[0] p-0 relative shrink-0 text-left text-nowrap">
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center relative shrink-0 text-[#202939] text-[24px]">
        <p className="block leading-[32px] text-nowrap whitespace-pre">
          Accelerate your savings
        </p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[#697586] text-[16px] whitespace-pre">
        <p className="block mb-0">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        </p>
        <p className="block">
          Suspendisse varius enim in eros elementum tristique.
        </p>
      </div>
    </div>
  );
}

function Frame1618872377() {
  return (
    <div className="box-border content-stretch flex flex-row gap-6 items-start justify-start p-0 relative shrink-0">
      <Frame2 />
      <Frame1618872372 />
    </div>
  );
}

function PieChart() {
  return (
    <div className="absolute left-2.5 size-7 top-2.5" data-name="pie-chart">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 28 28"
      >
        <g id="pie-chart">
          <path
            d={svgPaths.p18164d80}
            fill="var(--fill-0, #BA24D5)"
            id="Vector"
          />
          <path
            d={svgPaths.p36e8e4e0}
            fill="var(--fill-0, #BA24D5)"
            id="Vector_2"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame3() {
  return (
    <div
      className="bg-[#fbe8ff] relative rounded-[48px] shrink-0 size-12"
      data-name="frame"
    >
      <PieChart />
    </div>
  );
}

function Frame1618872373() {
  return (
    <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start leading-[0] p-0 relative shrink-0 text-left text-nowrap">
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center relative shrink-0 text-[#202939] text-[24px]">
        <p className="block leading-[32px] text-nowrap whitespace-pre">
          Built for growth
        </p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[#697586] text-[16px] whitespace-pre">
        <p className="block mb-0">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        </p>
        <p className="block">
          Suspendisse varius enim in eros elementum tristique.
        </p>
      </div>
    </div>
  );
}

function Frame1618872375() {
  return (
    <div className="box-border content-stretch flex flex-row gap-6 items-start justify-start p-0 relative shrink-0">
      <Frame3 />
      <Frame1618872373 />
    </div>
  );
}

function Frame1618872380() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-12 items-start justify-start left-20 p-0 top-[120px]">
      <Frame1618872378 />
      <div
        className="bg-[#e3e8ef] h-px shrink-0 w-[600px]"
        data-name="div#w-node-a13b889f-1187-650c-23d7-b9bb2a37c9fb-bb12ca57"
      />
      <Frame1618872377 />
      <div
        className="bg-[#e3e8ef] h-px shrink-0 w-[600px]"
        data-name="div#w-node-_6f861372-429c-2f77-b7ac-2c2dc4046f81-bb12ca57"
      />
      <Frame1618872375 />
    </div>
  );
}

function Frame4() {
  return (
    <div
      className="absolute bg-[50.12%_0%] bg-no-repeat bg-size-[100%_100%] h-[600px] left-[875.98px] top-[120px] w-[368px]"
      data-name="frame"
      style={{
        backgroundImage: `url('${img62B9A942C0B6351858401716Screen01Png}')`,
      }}
    />
  );
}

function Section06() {
  return (
    <div
      className="absolute h-[722px] left-0 right-0 top-[3063px]"
      data-name="Section 06"
    >
      <Frame1618872380 />
      <Frame4 />
    </div>
  );
}

function DivTagline2() {
  return (
    <div
      className="bg-[#f6d0fe] box-border content-stretch flex flex-row items-center justify-center px-3 py-1 relative rounded-3xl shrink-0"
      data-name="div.tagline"
    >
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ba24d5] text-[15px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Simple process</p>
      </div>
    </div>
  );
}

function Frame1618872416() {
  return (
    <div className="box-border content-stretch flex flex-col gap-4 items-center justify-start p-0 relative shrink-0">
      <DivTagline2 />
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#202939] text-[40px] text-center text-nowrap">
        <p className="block leading-[48px] whitespace-pre">How it works</p>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div
      className="bg-[#fbe8ff] relative rounded-[48px] shrink-0 size-12"
      data-name="Frame"
    >
      <div className="absolute flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] left-6 text-[#ba24d5] text-[24px] text-center text-nowrap top-6 translate-x-[-50%] translate-y-[-50%]">
        <p className="block leading-[32px] whitespace-pre">1</p>
      </div>
    </div>
  );
}

function Frame1618872422() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-5 items-center justify-start left-[40.5px] p-0 top-[42px]">
      <Frame5 />
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#202939] text-[24px] text-center w-[230px]">
        <p className="block leading-[32px]">{`Save, Invest & Track`}</p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[#697586] text-[16px] text-center text-nowrap whitespace-pre">
        <p className="block mb-0">Lorem ipsum dolor sit amet, consectetur</p>
        <p className="block">adipiscing elit. Suspendisse varius.</p>
      </div>
    </div>
  );
}

function Card() {
  return (
    <div
      className="bg-[#ffffff] h-[252px] relative rounded-2xl shrink-0 w-[405px]"
      data-name="card"
    >
      <div className="h-[252px] overflow-clip relative w-[405px]">
        <Frame1618872422 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#fbe8ff] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Frame6() {
  return (
    <div
      className="bg-[#fbe8ff] relative rounded-[48px] shrink-0 size-12"
      data-name="Frame"
    >
      <div className="absolute flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] left-6 text-[#ba24d5] text-[24px] text-center text-nowrap top-6 translate-x-[-50%] translate-y-[-50%]">
        <p className="block leading-[32px] whitespace-pre">2</p>
      </div>
    </div>
  );
}

function Frame1618872423() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-5 items-center justify-start left-[40.5px] p-0 top-[42px]">
      <Frame6 />
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#202939] text-[24px] text-center w-[230px]">
        <p className="block leading-[32px]">Send payment</p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[#697586] text-[16px] text-center text-nowrap whitespace-pre">
        <p className="block mb-0">Lorem ipsum dolor sit amet, consectetur</p>
        <p className="block">adipiscing elit. Suspendisse varius.</p>
      </div>
    </div>
  );
}

function Card1() {
  return (
    <div
      className="bg-[#ffffff] h-[252px] relative rounded-2xl shrink-0 w-[405px]"
      data-name="card"
    >
      <div className="h-[252px] overflow-clip relative w-[405px]">
        <Frame1618872423 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#fbe8ff] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Frame7() {
  return (
    <div
      className="bg-[#fbe8ff] relative rounded-[48px] shrink-0 size-12"
      data-name="Frame"
    >
      <div className="absolute flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] left-[23.5px] text-[#ba24d5] text-[24px] text-center text-nowrap top-6 translate-x-[-50%] translate-y-[-50%]">
        <p className="block leading-[32px] whitespace-pre">3</p>
      </div>
    </div>
  );
}

function Frame1618872424() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-5 items-center justify-start left-[40.5px] p-0 top-[42px]">
      <Frame7 />
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#202939] text-[24px] text-center w-[230px]">
        <p className="block leading-[32px]">Track profit</p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[#697586] text-[16px] text-center text-nowrap whitespace-pre">
        <p className="block mb-0">Lorem ipsum dolor sit amet, consectetur</p>
        <p className="block">adipiscing elit. Suspendisse varius.</p>
      </div>
    </div>
  );
}

function Card2() {
  return (
    <div
      className="bg-[#ffffff] h-[252px] relative rounded-2xl shrink-0 w-[405px]"
      data-name="card"
    >
      <div className="h-[252px] overflow-clip relative w-[405px]">
        <Frame1618872424 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#fbe8ff] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Frame1618872430() {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-start justify-start p-0 relative shrink-0">
      <Card />
      <Card1 />
      <Card2 />
    </div>
  );
}

function Frame1618872432() {
  return (
    <div className="box-border content-stretch flex flex-col gap-4 items-center justify-start leading-[0] p-0 relative shrink-0 text-center text-nowrap">
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center relative shrink-0 text-[#202939] text-[32px]">
        <p className="block leading-[41.6px] text-nowrap whitespace-pre">
          Still have questions?
        </p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center not-italic relative shrink-0 text-[#697586] text-[16px]">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        </p>
      </div>
    </div>
  );
}

function Link7() {
  return (
    <div
      className="bg-[#ffffff] box-border content-stretch flex flex-col items-center justify-center px-[25px] py-3 relative rounded-[32px] shrink-0"
      data-name="Link"
    >
      <div
        aria-hidden="true"
        className="absolute border border-[#364152] border-solid inset-0 pointer-events-none rounded-[32px]"
      />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Contact us</p>
      </div>
    </div>
  );
}

function Frame1618872433() {
  return (
    <div className="box-border content-stretch flex flex-col gap-6 items-center justify-start p-0 relative shrink-0">
      <Frame1618872432 />
      <Link7 />
    </div>
  );
}

function Frame1618872435() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-14 items-center justify-start left-20 p-0 top-[120px]">
      <Frame1618872416 />
      <Frame1618872430 />
      <Frame1618872433 />
    </div>
  );
}

function Section05() {
  return (
    <div
      className="absolute bg-fuchsia-50 h-[854px] left-0 top-[3785px] w-[1440px]"
      data-name="Section 05"
    >
      <Frame1618872435 />
    </div>
  );
}

function DivTagline3() {
  return (
    <div
      className="bg-[#ebeff5] box-border content-stretch flex flex-row items-center justify-center px-3 py-1 relative rounded-3xl shrink-0"
      data-name="div.tagline"
    >
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[15px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">
          What customers say
        </p>
      </div>
    </div>
  );
}

function Frame1618872460() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-4 items-center justify-start left-[498px] p-0 top-[120px]">
      <DivTagline3 />
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#202939] text-[40px] text-center text-nowrap">
        <p className="block leading-[48px] whitespace-pre">
          Customer testimonials
        </p>
      </div>
    </div>
  );
}

function Image() {
  return (
    <div
      className="bg-center bg-cover bg-no-repeat rounded-[48px] shrink-0 size-12"
      data-name="image"
      style={{ backgroundImage: `url('${imgImage}')` }}
    />
  );
}

function Frame1618872449() {
  return (
    <div className="box-border content-stretch flex flex-col gap-px items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[16px] text-left text-nowrap">
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center relative shrink-0 text-[#202939]">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Orlando Diggs
        </p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center relative shrink-0 text-[#697586]">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Position, Company name
        </p>
      </div>
    </div>
  );
}

function Frame1618872450() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-4 items-center justify-start left-8 p-0 top-[252px]">
      <Image />
      <Frame1618872449 />
    </div>
  );
}

function Star() {
  return (
    <div className="relative shrink-0 size-6" data-name="star">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="star">
          <path
            d={svgPaths.p3b22d580}
            fill="var(--fill-0, #FF881B)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872443() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-1 items-start justify-start left-8 p-0 top-8">
      {[...Array(5).keys()].map((_, i) => (
        <Star key={i} />
      ))}
    </div>
  );
}

function Testimonial1() {
  return (
    <div
      className="bg-[#ffffff] h-[335px] relative rounded-2xl shrink-0 w-[400px]"
      data-name="testimonial-1"
    >
      <div className="h-[335px] overflow-clip relative w-[400px]">
        <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[28px] left-8 not-italic text-[#697586] text-[18px] text-left text-nowrap top-[150px] translate-y-[-50%] whitespace-pre">
          <p className="block mb-0">{`"Lorem ipsum dolor sit amet,`}</p>
          <p className="block mb-0">consectetur adipiscing elit.</p>
          <p className="block mb-0">Suspendisse varius enim in eros</p>
          <p className="block mb-0">elementum tristique. Duis cursus, mi</p>
          <p className="block">{`quis viverra ornare."`}</p>
        </div>
        <Frame1618872450 />
        <Frame1618872443 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#eef2f6] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Image1() {
  return (
    <div
      className="bg-center bg-cover bg-no-repeat rounded-[48px] shrink-0 size-12"
      data-name="image"
      style={{ backgroundImage: `url('${imgImage1}')` }}
    />
  );
}

function Frame1618872452() {
  return (
    <div className="box-border content-stretch flex flex-col gap-px items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[16px] text-left text-nowrap">
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center relative shrink-0 text-[#202939]">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Mollie Hall
        </p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center relative shrink-0 text-[#697586]">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Position, Company name
        </p>
      </div>
    </div>
  );
}

function Frame1618872453() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-4 items-center justify-start left-[33px] p-0 top-[252px]">
      <Image1 />
      <Frame1618872452 />
    </div>
  );
}

function Star5() {
  return (
    <div className="relative shrink-0 size-6" data-name="star">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="star">
          <path
            d={svgPaths.p3b22d580}
            fill="var(--fill-0, #FF881B)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872444() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-1 items-start justify-start left-8 p-0 top-8">
      {[...Array(5).keys()].map((_, i) => (
        <Star5 key={i} />
      ))}
    </div>
  );
}

function Testimonial2() {
  return (
    <div
      className="bg-[#ffffff] h-[335px] relative rounded-2xl shrink-0 w-[400px]"
      data-name="testimonial-2"
    >
      <div className="h-[335px] overflow-clip relative w-[400px]">
        <Frame1618872453 />
        <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[28px] left-8 not-italic text-[#697586] text-[18px] text-left text-nowrap top-[150px] translate-y-[-50%] whitespace-pre">
          <p className="block mb-0">{`"Lorem ipsum dolor sit amet,`}</p>
          <p className="block mb-0">consectetur adipiscing elit.</p>
          <p className="block mb-0">Suspendisse varius enim in eros</p>
          <p className="block mb-0">elementum tristique. Duis cursus, mi</p>
          <p className="block">{`quis viverra ornare."`}</p>
        </div>
        <Frame1618872444 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#eef2f6] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Image2() {
  return (
    <div
      className="bg-center bg-cover bg-no-repeat rounded-[48px] shrink-0 size-12"
      data-name="image"
      style={{ backgroundImage: `url('${imgImage2}')` }}
    />
  );
}

function Frame1618872454() {
  return (
    <div className="box-border content-stretch flex flex-col gap-px items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[16px] text-left text-nowrap">
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center relative shrink-0 text-[#202939]">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Lori Bryson
        </p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center relative shrink-0 text-[#697586]">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Position, Company name
        </p>
      </div>
    </div>
  );
}

function Frame1618872455() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-4 items-center justify-start left-[33px] p-0 top-[252px]">
      <Image2 />
      <Frame1618872454 />
    </div>
  );
}

function Star10() {
  return (
    <div className="relative shrink-0 size-6" data-name="star">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="star">
          <path
            d={svgPaths.p3b22d580}
            fill="var(--fill-0, #FF881B)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872445() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-1 items-start justify-start left-8 p-0 top-8">
      {[...Array(5).keys()].map((_, i) => (
        <Star10 key={i} />
      ))}
    </div>
  );
}

function Testimonial3() {
  return (
    <div
      className="bg-[#ffffff] h-[335px] relative rounded-2xl shrink-0 w-[400px]"
      data-name="testimonial-3"
    >
      <div className="h-[335px] overflow-clip relative w-[400px]">
        <Frame1618872455 />
        <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[28px] left-8 not-italic text-[#697586] text-[18px] text-left text-nowrap top-[150px] translate-y-[-50%] whitespace-pre">
          <p className="block mb-0">{`"Lorem ipsum dolor sit amet,`}</p>
          <p className="block mb-0">consectetur adipiscing elit.</p>
          <p className="block mb-0">Suspendisse varius enim in eros</p>
          <p className="block mb-0">elementum tristique. Duis cursus, mi</p>
          <p className="block">{`quis viverra ornare."`}</p>
        </div>
        <Frame1618872445 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#eef2f6] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Image3() {
  return (
    <div
      className="bg-center bg-cover bg-no-repeat rounded-[48px] shrink-0 size-12"
      data-name="image"
      style={{ backgroundImage: `url('${imgImage3}')` }}
    />
  );
}

function Frame1618872456() {
  return (
    <div className="box-border content-stretch flex flex-col gap-px items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[16px] text-left text-nowrap">
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center relative shrink-0 text-[#202939]">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Kate Morrison
        </p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center relative shrink-0 text-[#697586]">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Position, Company name
        </p>
      </div>
    </div>
  );
}

function Frame1618872457() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-4 items-center justify-start left-[33px] p-0 top-[252px]">
      <Image3 />
      <Frame1618872456 />
    </div>
  );
}

function Star15() {
  return (
    <div className="relative shrink-0 size-6" data-name="star">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="star">
          <path
            d={svgPaths.p3b22d580}
            fill="var(--fill-0, #FF881B)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame1618872446() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-1 items-start justify-start left-8 p-0 top-8">
      {[...Array(5).keys()].map((_, i) => (
        <Star15 key={i} />
      ))}
    </div>
  );
}

function Testimonial4() {
  return (
    <div
      className="bg-[#ffffff] h-[335px] relative rounded-2xl shrink-0 w-[400px]"
      data-name="testimonial-4"
    >
      <div className="h-[335px] overflow-clip relative w-[400px]">
        <Frame1618872457 />
        <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[28px] left-8 not-italic text-[#697586] text-[18px] text-left text-nowrap top-[150px] translate-y-[-50%] whitespace-pre">
          <p className="block mb-0">{`"Lorem ipsum dolor sit amet,`}</p>
          <p className="block mb-0">consectetur adipiscing elit.</p>
          <p className="block mb-0">Suspendisse varius enim in eros</p>
          <p className="block mb-0">elementum tristique. Duis cursus, mi</p>
          <p className="block">{`quis viverra ornare."`}</p>
        </div>
        <Frame1618872446 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#eef2f6] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Frame1618872459() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-8 items-start justify-start left-20 p-0 top-[296px]">
      <Testimonial1 />
      <Testimonial2 />
      <Testimonial3 />
      <Testimonial4 />
    </div>
  );
}

function Group1321314419() {
  return (
    <div className="absolute contents left-20 top-[120px]">
      <Frame1618872460 />
      <Frame1618872459 />
    </div>
  );
}

function Section04() {
  return (
    <div
      className="absolute bg-[#ffffff] h-[751px] left-0 overflow-clip right-0 top-[4639px]"
      data-name="Section 04"
    >
      <Group1321314419 />
    </div>
  );
}

function DivTagline4() {
  return (
    <div
      className="bg-[#ebeff5] box-border content-stretch flex flex-row items-center justify-center px-3 py-1 relative rounded-3xl shrink-0"
      data-name="div.tagline"
    >
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[15px] text-left text-nowrap">
        <p className="block leading-[22.5px] whitespace-pre">Blog</p>
      </div>
    </div>
  );
}

function Frame1618872472() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-4 items-start justify-start ml-0 mt-0 p-0 relative">
      <DivTagline4 />
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#202939] text-[40px] text-left text-nowrap">
        <p className="block leading-[48px] whitespace-pre">Our latest blogs</p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        </p>
      </div>
    </div>
  );
}

function Link8() {
  return (
    <div
      className="[grid-area:1_/_1] bg-[#ffffff] box-border content-stretch flex flex-col items-center justify-center ml-[1168px] mt-[81px] px-[25px] py-3 relative rounded-[32px]"
      data-name="Link"
    >
      <div
        aria-hidden="true"
        className="absolute border border-[#364152] border-solid inset-0 pointer-events-none rounded-[32px]"
      />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">View all</p>
      </div>
    </div>
  );
}

function Group1321314426() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Frame1618872472 />
      <Link8 />
    </div>
  );
}

function Component62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg() {
  return (
    <div
      className="absolute bg-no-repeat bg-size-[188.46%_100%] bg-top inset-0"
      data-name="62a0d08b38d0a055f41b47d7_pawel-czerwinski-jkwWCG6wYcI-unsplash-p-500.jpeg"
      style={{
        backgroundImage: `url('${img62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg}')`,
      }}
    />
  );
}

function Link9() {
  return (
    <a
      className="absolute block bottom-px cursor-pointer left-px overflow-clip right-[352px] top-px"
      data-name="Link"
      href="https://financiotemplate.webflow.io/post/how-much-should-i-have-saved-in-my-401-k-by-age"
    >
      <Component62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg />
    </a>
  );
}

function Link10() {
  return (
    <a
      className="absolute bg-[#f6d0fe] box-border content-stretch cursor-pointer flex flex-row items-center justify-center left-8 overflow-visible px-3 py-1 rounded-3xl top-8"
      data-name="Link"
      href="https://financiotemplate.webflow.io/blog-categories/investments"
    >
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ba24d5] text-[15px] text-left text-nowrap">
        <p className="block leading-[22.5px] whitespace-pre">Investments</p>
      </div>
    </a>
  );
}

function Component62A0B8731B0B805Dada6D664Image2P500Jpeg() {
  return (
    <div
      className="bg-center bg-cover bg-no-repeat max-w-12 min-h-12 min-w-12 rounded-[48px] shrink-0 size-12"
      data-name="62a0b8731b0b805dada6d664_Image-2-p-500.jpeg"
      style={{
        backgroundImage: `url('${img62A0B8731B0B805Dada6D664Image2P500Jpeg}')`,
      }}
    />
  );
}

function DivBlog1AuthorImageWrapper() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-center p-0 relative shrink-0"
      data-name="div.blog-1-author-image-wrapper"
    >
      <Component62A0B8731B0B805Dada6D664Image2P500Jpeg />
    </div>
  );
}

function DivTextSizeSmall() {
  return (
    <div
      className="h-[22px] relative shrink-0 w-full"
      data-name="div.text-size-small"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pl-0 pr-[95.37px] pt-0 relative w-full">
          <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[14px] text-left text-nowrap">
            <p className="block leading-[21px] whitespace-pre">Lana Steiner</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DivTextSizeSmall1() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pt-0 px-0 relative shrink-0"
      data-name="div.text-size-small"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[14px] text-left text-nowrap">
        <p className="block leading-[21px] whitespace-pre">June 8, 2022</p>
      </div>
    </div>
  );
}

function DivBlog1TextDividerMargin() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start px-2 py-0 relative shrink-0"
      data-name="div.blog-1-text-divider:margin"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">•</p>
      </div>
    </div>
  );
}

function DivTextSizeSmall2() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pt-0 px-0 relative shrink-0"
      data-name="div.text-size-small"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[14px] text-left text-nowrap">
        <p className="block leading-[21px] whitespace-pre">7 min read</p>
      </div>
    </div>
  );
}

function DivBlog1DateWrapper() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-center justify-start p-0 relative shrink-0 w-full"
      data-name="div.blog-1-date-wrapper"
    >
      <DivTextSizeSmall1 />
      <DivBlog1TextDividerMargin />
      <DivTextSizeSmall2 />
    </div>
  );
}

function DivBlog1AuthorText() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[46px] items-start justify-start p-0 relative shrink-0"
      data-name="div.blog-1-author-text"
    >
      <DivTextSizeSmall />
      <DivBlog1DateWrapper />
    </div>
  );
}

function Frame1618872489() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-3 items-center justify-start left-8 p-0 top-[237px]">
      <DivBlog1AuthorImageWrapper />
      <DivBlog1AuthorText />
    </div>
  );
}

function ArrowDown5() {
  return (
    <div className="relative size-4" data-name="arrow-down-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-down-01">
          <path
            d="M4 6.00003L8 10L12 6"
            id="Vector"
            stroke="var(--stroke-0, #364152)"
            strokeMiterlimit="16"
            strokeWidth="1.5"
          />
        </g>
      </svg>
    </div>
  );
}

function Div4() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row gap-2 items-center justify-start left-8 p-0 top-[329px]"
      data-name="div"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Read more</p>
      </div>
      <div className="flex h-[15.984px] items-center justify-center relative shrink-0 w-[15.984px]">
        <div className="flex-none rotate-[270deg]">
          <ArrowDown5 />
        </div>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div
      className="absolute bottom-px left-[264px] right-px top-px"
      data-name="content"
    >
      <Link10 />
      <div className="absolute flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[32px] left-8 text-[#202939] text-[24px] text-left top-[127px] translate-y-[-50%] w-[287px]">
        <p className="block mb-0">How much should I have</p>
        <p className="block">saved in my 401 (k) by age?</p>
      </div>
      <Frame1618872489 />
      <Div4 />
    </div>
  );
}

function Listitem() {
  return (
    <div
      className="bg-[#ffffff] h-[379px] relative rounded-2xl shrink-0 w-[616px]"
      data-name="Listitem"
    >
      <div className="h-[379px] overflow-clip relative w-[616px]">
        <Link9 />
        <Content />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#e3e8ef] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Component62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg1() {
  return (
    <div
      className="absolute bg-no-repeat bg-size-[188.46%_100%] bg-top inset-0"
      data-name="62a0d08b38d0a055f41b47d7_pawel-czerwinski-jkwWCG6wYcI-unsplash-p-500.jpeg"
      style={{
        backgroundImage: `url('${img62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg1}')`,
      }}
    />
  );
}

function Link11() {
  return (
    <a
      className="absolute block bottom-px cursor-pointer left-px overflow-clip right-[352px] top-px"
      data-name="Link"
      href="https://financiotemplate.webflow.io/post/how-much-should-i-have-saved-in-my-401-k-by-age"
    >
      <Component62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg1 />
    </a>
  );
}

function Link12() {
  return (
    <a
      className="absolute bg-[#f6d0fe] box-border content-stretch cursor-pointer flex flex-row items-center justify-center left-8 overflow-visible px-3 py-1 rounded-3xl top-8"
      data-name="Link"
      href="https://financiotemplate.webflow.io/blog-categories/investments"
    >
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ba24d5] text-[15px] text-left text-nowrap">
        <p className="block leading-[22.5px] whitespace-pre">Investments</p>
      </div>
    </a>
  );
}

function Component62A0B8731B0B805Dada6D664Image2P500Jpeg1() {
  return (
    <div
      className="bg-center bg-cover bg-no-repeat max-w-12 min-h-12 min-w-12 rounded-[48px] shrink-0 size-12"
      data-name="62a0b8731b0b805dada6d664_Image-2-p-500.jpeg"
      style={{
        backgroundImage: `url('${img62A0B8731B0B805Dada6D664Image2P500Jpeg1}')`,
      }}
    />
  );
}

function DivBlog1AuthorImageWrapper1() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-center p-0 relative shrink-0"
      data-name="div.blog-1-author-image-wrapper"
    >
      <Component62A0B8731B0B805Dada6D664Image2P500Jpeg1 />
    </div>
  );
}

function DivTextSizeSmall3() {
  return (
    <div
      className="h-[22px] relative shrink-0 w-full"
      data-name="div.text-size-small"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pl-0 pr-[95.37px] pt-0 relative w-full">
          <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[14px] text-left text-nowrap">
            <p className="block leading-[21px] whitespace-pre">Ava Wright</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DivTextSizeSmall4() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pt-0 px-0 relative shrink-0"
      data-name="div.text-size-small"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[14px] text-left text-nowrap">
        <p className="block leading-[21px] whitespace-pre">June 8, 2022</p>
      </div>
    </div>
  );
}

function DivBlog1TextDividerMargin1() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start px-2 py-0 relative shrink-0"
      data-name="div.blog-1-text-divider:margin"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">•</p>
      </div>
    </div>
  );
}

function DivTextSizeSmall5() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pt-0 px-0 relative shrink-0"
      data-name="div.text-size-small"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[14px] text-left text-nowrap">
        <p className="block leading-[21px] whitespace-pre">7 min read</p>
      </div>
    </div>
  );
}

function DivBlog1DateWrapper1() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-center justify-start p-0 relative shrink-0 w-full"
      data-name="div.blog-1-date-wrapper"
    >
      <DivTextSizeSmall4 />
      <DivBlog1TextDividerMargin1 />
      <DivTextSizeSmall5 />
    </div>
  );
}

function DivBlog1AuthorText1() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[46px] items-start justify-start p-0 relative shrink-0"
      data-name="div.blog-1-author-text"
    >
      <DivTextSizeSmall3 />
      <DivBlog1DateWrapper1 />
    </div>
  );
}

function Frame1618872490() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-3 items-center justify-start left-8 p-0 top-[237px]">
      <DivBlog1AuthorImageWrapper1 />
      <DivBlog1AuthorText1 />
    </div>
  );
}

function ArrowDown6() {
  return (
    <div className="relative size-4" data-name="arrow-down-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-down-01">
          <path
            d="M4 6.00003L8 10L12 6"
            id="Vector"
            stroke="var(--stroke-0, #364152)"
            strokeMiterlimit="16"
            strokeWidth="1.5"
          />
        </g>
      </svg>
    </div>
  );
}

function Div5() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row gap-2 items-center justify-start left-8 p-0 top-[329px]"
      data-name="div"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Read more</p>
      </div>
      <div className="flex h-[15.984px] items-center justify-center relative shrink-0 w-[15.984px]">
        <div className="flex-none rotate-[270deg]">
          <ArrowDown6 />
        </div>
      </div>
    </div>
  );
}

function Content1() {
  return (
    <div
      className="absolute bottom-px left-[264px] right-px top-px"
      data-name="content"
    >
      <Link12 />
      <div className="absolute flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[32px] left-8 text-[#202939] text-[24px] text-left top-[127px] translate-y-[-50%] w-[287px]">
        <p className="block mb-0">Reason to get whole life</p>
        <p className="block mb-0">insurance event though</p>
        <p className="block">it’s more expensive</p>
      </div>
      <Frame1618872490 />
      <Div5 />
    </div>
  );
}

function Listitem1() {
  return (
    <div
      className="bg-[#ffffff] h-[379px] relative rounded-2xl shrink-0 w-[616px]"
      data-name="Listitem"
    >
      <div className="h-[379px] overflow-clip relative w-[616px]">
        <Link11 />
        <Content1 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#e3e8ef] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Frame1618872509() {
  return (
    <div className="box-border content-stretch flex flex-row gap-12 items-start justify-start p-0 relative shrink-0">
      <Listitem />
      <Listitem1 />
    </div>
  );
}

function Component62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg2() {
  return (
    <div
      className="absolute bg-no-repeat bg-size-[188.46%_100%] bg-top inset-0"
      data-name="62a0d08b38d0a055f41b47d7_pawel-czerwinski-jkwWCG6wYcI-unsplash-p-500.jpeg"
      style={{
        backgroundImage: `url('${img62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg2}'), url('${img62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg}')`,
      }}
    />
  );
}

function Link13() {
  return (
    <a
      className="absolute block bottom-px cursor-pointer left-px overflow-clip right-[352px] top-px"
      data-name="Link"
      href="https://financiotemplate.webflow.io/post/how-much-should-i-have-saved-in-my-401-k-by-age"
    >
      <Component62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg2 />
    </a>
  );
}

function Link14() {
  return (
    <a
      className="absolute bg-[#f6d0fe] box-border content-stretch cursor-pointer flex flex-row items-center justify-center left-8 overflow-visible px-3 py-1 rounded-3xl top-8"
      data-name="Link"
      href="https://financiotemplate.webflow.io/blog-categories/investments"
    >
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ba24d5] text-[15px] text-left text-nowrap">
        <p className="block leading-[22.5px] whitespace-pre">Education</p>
      </div>
    </a>
  );
}

function Component62A0B8731B0B805Dada6D664Image2P500Jpeg2() {
  return (
    <div
      className="bg-center bg-cover bg-no-repeat max-w-12 min-h-12 min-w-12 rounded-[48px] shrink-0 size-12"
      data-name="62a0b8731b0b805dada6d664_Image-2-p-500.jpeg"
      style={{
        backgroundImage: `url('${img62A0B8731B0B805Dada6D664Image2P500Jpeg2}')`,
      }}
    />
  );
}

function DivBlog1AuthorImageWrapper2() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-center p-0 relative shrink-0"
      data-name="div.blog-1-author-image-wrapper"
    >
      <Component62A0B8731B0B805Dada6D664Image2P500Jpeg2 />
    </div>
  );
}

function DivTextSizeSmall6() {
  return (
    <div
      className="h-[22px] relative shrink-0 w-full"
      data-name="div.text-size-small"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pl-0 pr-[95.37px] pt-0 relative w-full">
          <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[14px] text-left text-nowrap">
            <p className="block leading-[21px] whitespace-pre">Lana Steiner</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DivTextSizeSmall7() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pt-0 px-0 relative shrink-0"
      data-name="div.text-size-small"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[14px] text-left text-nowrap">
        <p className="block leading-[21px] whitespace-pre">June 8, 2022</p>
      </div>
    </div>
  );
}

function DivBlog1TextDividerMargin2() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start px-2 py-0 relative shrink-0"
      data-name="div.blog-1-text-divider:margin"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">•</p>
      </div>
    </div>
  );
}

function DivTextSizeSmall8() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pt-0 px-0 relative shrink-0"
      data-name="div.text-size-small"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[14px] text-left text-nowrap">
        <p className="block leading-[21px] whitespace-pre">7 min read</p>
      </div>
    </div>
  );
}

function DivBlog1DateWrapper2() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-center justify-start p-0 relative shrink-0"
      data-name="div.blog-1-date-wrapper"
    >
      <DivTextSizeSmall7 />
      <DivBlog1TextDividerMargin2 />
      <DivTextSizeSmall8 />
    </div>
  );
}

function DivBlog1AuthorText2() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[46px] items-start justify-start p-0 relative shrink-0"
      data-name="div.blog-1-author-text"
    >
      <DivTextSizeSmall6 />
      <DivBlog1DateWrapper2 />
    </div>
  );
}

function Frame1618872491() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-3 items-center justify-start left-8 p-0 top-[241px]">
      <DivBlog1AuthorImageWrapper2 />
      <DivBlog1AuthorText2 />
    </div>
  );
}

function ArrowDown7() {
  return (
    <div className="relative size-4" data-name="arrow-down-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-down-01">
          <path
            d="M4 6.00003L8 10L12 6"
            id="Vector"
            stroke="var(--stroke-0, #364152)"
            strokeMiterlimit="16"
            strokeWidth="1.5"
          />
        </g>
      </svg>
    </div>
  );
}

function Div6() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row gap-2 items-center justify-start left-8 p-0 top-[329px]"
      data-name="div"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Read more</p>
      </div>
      <div className="flex h-[15.984px] items-center justify-center relative shrink-0 w-[15.984px]">
        <div className="flex-none rotate-[270deg]">
          <ArrowDown7 />
        </div>
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div
      className="absolute bottom-px left-[264px] right-px top-px"
      data-name="content"
    >
      <Link14 />
      <div className="absolute flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[32px] left-8 text-[#202939] text-[24px] text-left top-[127px] translate-y-[-50%] w-[287px]">
        <p className="block mb-0">How much money do the</p>
        <p className="block mb-0">top income earners</p>
        <p className="block">make?</p>
      </div>
      <Frame1618872491 />
      <Div6 />
    </div>
  );
}

function Listitem2() {
  return (
    <div
      className="bg-[#ffffff] h-[379px] relative rounded-2xl shrink-0 w-[616px]"
      data-name="Listitem"
    >
      <div className="h-[379px] overflow-clip relative w-[616px]">
        <Link13 />
        <Content2 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#e3e8ef] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Component62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg3() {
  return (
    <div
      className="absolute bg-no-repeat bg-size-[200.5%_100%,188.46%_100%] bg-top inset-0"
      data-name="62a0d08b38d0a055f41b47d7_pawel-czerwinski-jkwWCG6wYcI-unsplash-p-500.jpeg"
      style={{
        backgroundImage: `url('${img62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg3}'), url('${img62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg}')`,
      }}
    />
  );
}

function Link15() {
  return (
    <a
      className="absolute block bottom-px cursor-pointer left-px overflow-clip right-[352px] top-px"
      data-name="Link"
      href="https://financiotemplate.webflow.io/post/how-much-should-i-have-saved-in-my-401-k-by-age"
    >
      <Component62A0D08B38D0A055F41B47D7PawelCzerwinskiJkwWcg6WYcIUnsplashP500Jpeg3 />
    </a>
  );
}

function Link16() {
  return (
    <a
      className="absolute bg-[#f6d0fe] box-border content-stretch cursor-pointer flex flex-row items-center justify-center left-8 overflow-visible px-3 py-1 rounded-3xl top-8"
      data-name="Link"
      href="https://financiotemplate.webflow.io/blog-categories/investments"
    >
      <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ba24d5] text-[15px] text-left text-nowrap">
        <p className="block leading-[22.5px] whitespace-pre">Investments</p>
      </div>
    </a>
  );
}

function Component62A0B8731B0B805Dada6D664Image2P500Jpeg3() {
  return (
    <div
      className="bg-center bg-cover bg-no-repeat max-w-12 min-h-12 min-w-12 rounded-[48px] shrink-0 size-12"
      data-name="62a0b8731b0b805dada6d664_Image-2-p-500.jpeg"
      style={{
        backgroundImage: `url('${img62A0B8731B0B805Dada6D664Image2P500Jpeg3}')`,
      }}
    />
  );
}

function DivBlog1AuthorImageWrapper3() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-center p-0 relative shrink-0"
      data-name="div.blog-1-author-image-wrapper"
    >
      <Component62A0B8731B0B805Dada6D664Image2P500Jpeg3 />
    </div>
  );
}

function DivTextSizeSmall9() {
  return (
    <div
      className="h-[22px] relative shrink-0 w-full"
      data-name="div.text-size-small"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pl-0 pr-[95.37px] pt-0 relative w-full">
          <div className="flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#202939] text-[14px] text-left text-nowrap">
            <p className="block leading-[21px] whitespace-pre">Ava Wright</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DivTextSizeSmall10() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pt-0 px-0 relative shrink-0"
      data-name="div.text-size-small"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[14px] text-left text-nowrap">
        <p className="block leading-[21px] whitespace-pre">June 8, 2022</p>
      </div>
    </div>
  );
}

function DivBlog1TextDividerMargin3() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start px-2 py-0 relative shrink-0"
      data-name="div.blog-1-text-divider:margin"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[16px] text-left text-nowrap">
        <p className="block leading-[24px] whitespace-pre">•</p>
      </div>
    </div>
  );
}

function DivTextSizeSmall11() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[22px] items-start justify-start pb-[0.5px] pt-0 px-0 relative shrink-0"
      data-name="div.text-size-small"
    >
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#697586] text-[14px] text-left text-nowrap">
        <p className="block leading-[21px] whitespace-pre">7 min read</p>
      </div>
    </div>
  );
}

function DivBlog1DateWrapper3() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-center justify-start p-0 relative shrink-0 w-full"
      data-name="div.blog-1-date-wrapper"
    >
      <DivTextSizeSmall10 />
      <DivBlog1TextDividerMargin3 />
      <DivTextSizeSmall11 />
    </div>
  );
}

function DivBlog1AuthorText3() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[46px] items-start justify-start p-0 relative shrink-0"
      data-name="div.blog-1-author-text"
    >
      <DivTextSizeSmall9 />
      <DivBlog1DateWrapper3 />
    </div>
  );
}

function Frame1618872492() {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-3 items-center justify-start left-8 p-0 top-[241px]">
      <DivBlog1AuthorImageWrapper3 />
      <DivBlog1AuthorText3 />
    </div>
  );
}

function ArrowDown8() {
  return (
    <div className="relative size-4" data-name="arrow-down-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-down-01">
          <path
            d="M4 6.00003L8 10L12 6"
            id="Vector"
            stroke="var(--stroke-0, #364152)"
            strokeMiterlimit="16"
            strokeWidth="1.5"
          />
        </g>
      </svg>
    </div>
  );
}

function Div7() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row gap-2 items-center justify-start left-8 p-0 top-[329px]"
      data-name="div"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Read more</p>
      </div>
      <div className="flex h-[15.984px] items-center justify-center relative shrink-0 w-[15.984px]">
        <div className="flex-none rotate-[270deg]">
          <ArrowDown8 />
        </div>
      </div>
    </div>
  );
}

function Content3() {
  return (
    <div
      className="absolute bottom-px left-[264px] right-px top-px"
      data-name="content"
    >
      <Link16 />
      <div className="absolute flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[32px] left-8 text-[#202939] text-[24px] text-left top-[111px] translate-y-[-50%] w-[287px]">
        <p className="block mb-0">How to retire early and</p>
        <p className="block">never have to work again</p>
      </div>
      <Frame1618872492 />
      <Div7 />
    </div>
  );
}

function Listitem3() {
  return (
    <div
      className="bg-[#ffffff] h-[379px] relative rounded-2xl shrink-0 w-[616px]"
      data-name="Listitem"
    >
      <div className="h-[379px] overflow-clip relative w-[616px]">
        <Link15 />
        <Content3 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-[#e3e8ef] border-solid inset-0 pointer-events-none rounded-2xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
    </div>
  );
}

function Frame1618872510() {
  return (
    <div className="box-border content-stretch flex flex-row gap-12 items-start justify-start p-0 relative shrink-0">
      <Listitem2 />
      <Listitem3 />
    </div>
  );
}

function Frame1618872511() {
  return (
    <div className="box-border content-stretch flex flex-col gap-8 items-start justify-start p-0 relative shrink-0">
      <Frame1618872509 />
      <Frame1618872510 />
    </div>
  );
}

function Frame1618872512() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-[60px] items-start justify-start left-20 p-0 top-[100px]">
      <Group1321314426 />
      <Frame1618872511 />
    </div>
  );
}

function Section03() {
  return (
    <div
      className="absolute bg-[#f6f6f6] h-[1185px] left-0 right-0 top-[5390px]"
      data-name="Section 03"
    >
      <Frame1618872512 />
    </div>
  );
}

function Link17() {
  return (
    <div
      className="bg-[#ffffff] box-border content-stretch flex flex-col items-center justify-start px-6 py-3 relative rounded-[32px] shrink-0"
      data-name="Link"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#364152] text-[16px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Get started</p>
      </div>
    </div>
  );
}

function Div8() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[17px] items-center justify-start pb-[0.5px] pt-0 px-0 relative shrink-0"
      data-name="div"
    >
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[16px] text-center text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Log in</p>
      </div>
    </div>
  );
}

function Svg() {
  return (
    <div className="relative shrink-0 size-5" data-name="SVG">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="SVG">
          <path
            d={svgPaths.p3568d780}
            fill="var(--fill-0, white)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function DivWEmbed() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-start pb-[3px] pt-0 px-0 relative shrink-0"
      data-name="div.w-embed"
    >
      <Svg />
    </div>
  );
}

function Link18() {
  return (
    <a
      className="box-border content-stretch cursor-pointer flex flex-row gap-2 items-center justify-start max-w-[768px] overflow-visible px-0 py-1 relative shrink-0"
      data-name="Link"
      href="https://financiotemplate.webflow.io/account-pages/log-in"
    >
      <Div8 />
      <DivWEmbed />
    </a>
  );
}

function Frame1618872515() {
  return (
    <div className="box-border content-stretch flex flex-row gap-4 items-center justify-start p-0 relative shrink-0">
      <Link17 />
      <Link18 />
    </div>
  );
}

function Frame1618872523() {
  return (
    <div className="box-border content-stretch flex flex-col gap-10 items-center justify-start p-0 relative shrink-0">
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[27px] not-italic relative shrink-0 text-[#b8b8b8] text-[18px] text-center text-nowrap whitespace-pre">
        <p className="block mb-0">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in
        </p>
        <p className="block">eros elementum tristique duis.</p>
      </div>
      <Frame1618872515 />
    </div>
  );
}

function Frame1618872524() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-6 items-start justify-start left-[347.5px] p-0 top-[120px]">
      <div className="flex flex-col font-['Manrope:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#ffffff] text-[40px] text-center text-nowrap">
        <p className="block leading-[48px] whitespace-pre">
          Get the app on your preferred platform
        </p>
      </div>
      <Frame1618872523 />
    </div>
  );
}

function Section02() {
  return (
    <div
      className="absolute bg-[#0e1624] h-[454px] left-0 right-0 top-[6575px]"
      data-name="Section 02"
    >
      <Frame1618872524 />
    </div>
  );
}

function Frame1618872606() {
  return (
    <div className="absolute bg-[#ffffff] box-border content-stretch flex flex-row gap-2.5 items-center justify-start left-[944px] p-[10px] rounded-xl top-[174px] w-[269px]">
      <div
        aria-hidden="true"
        className="absolute border border-[#eef2f6] border-solid inset-0 pointer-events-none rounded-xl shadow-[0px_4px_6px_-2px_rgba(16,24,40,0.03),0px_12px_16px_-4px_rgba(16,24,40,0.08)]"
      />
      <div className="flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#999999] text-[14px] text-left text-nowrap">
        <p className="block leading-[normal] whitespace-pre">
          Enter your email
        </p>
      </div>
    </div>
  );
}

function Frame1618872612() {
  return (
    <div className="absolute bg-[#202939] box-border content-stretch flex flex-col items-center justify-center left-[1229px] px-[25px] py-3 rounded-[32px] top-[171px]">
      <div
        aria-hidden="true"
        className="absolute border border-[#202939] border-solid inset-0 pointer-events-none rounded-[32px] shadow-[0px_4px_8px_-2px_rgba(0,0,0,0.1),0px_2px_4px_-2px_rgba(0,0,0,0.06)]"
      />
      <div className="flex flex-col font-['Poppins:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[16px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Subscribe</p>
      </div>
    </div>
  );
}

function Frame1618872581() {
  return (
    <div className="absolute box-border content-stretch flex flex-row font-['Poppins:Regular',_sans-serif] gap-1 items-start justify-start leading-[0] left-20 not-italic p-0 text-[#697586] text-[0px] text-left text-nowrap top-[545px]">
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="leading-[21px] text-[14px] text-nowrap whitespace-pre">
          <span>{`© Financio by `}</span>
          <span className="font-['Poppins:Regular',_sans-serif] not-italic text-[#697586]">
            Minimal Square
          </span>
          .
        </p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="leading-[21px] text-[14px] text-nowrap whitespace-pre">
          <span>{`Powered by `}</span>
          <span className="font-['Poppins:Regular',_sans-serif] not-italic text-[#697586]">
            Webflow
          </span>
          .
        </p>
      </div>
    </div>
  );
}

function Group1321314448() {
  return (
    <div className="absolute left-[1195px] size-8 top-[540px]">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 32 32"
      >
        <g id="Group 1321314448">
          <path
            d={svgPaths.p37cbd980}
            fill="var(--fill-0, #FBE8FF)"
            id="link"
          />
          <g id="facebook-02">
            <path
              clipRule="evenodd"
              d={svgPaths.p2c417800}
              fill="var(--fill-0, #BA24D5)"
              fillRule="evenodd"
              id="Vector"
            />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Group1321314449() {
  return (
    <div className="absolute left-[1239px] size-8 top-[540px]">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 32 32"
      >
        <g id="Group 1321314449">
          <path
            d={svgPaths.p37cbd980}
            fill="var(--fill-0, #FBE8FF)"
            id="link"
          />
          <g id="new-twitter">
            <path
              d={svgPaths.p1348aa00}
              fill="var(--fill-0, #BA24D5)"
              id="Vector"
            />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Group1321314450() {
  return (
    <div className="absolute left-[1283px] size-8 top-[540px]">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 32 32"
      >
        <g id="Group 1321314450">
          <path
            d={svgPaths.p37cbd980}
            fill="var(--fill-0, #FBE8FF)"
            id="link"
          />
          <g id="linkedin-01">
            <path
              clipRule="evenodd"
              d={svgPaths.p16d3df00}
              fill="var(--fill-0, #BA24D5)"
              fillRule="evenodd"
              id="Vector"
            />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Group1321314451() {
  return (
    <div className="absolute left-[1327px] size-8 top-[540px]">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 32 32"
      >
        <g id="Group 1321314451">
          <path
            d={svgPaths.p37cbd980}
            fill="var(--fill-0, #FBE8FF)"
            id="link"
          />
          <g id="instagram">
            <path
              clipRule="evenodd"
              d={svgPaths.p7451500}
              fill="var(--fill-0, #BA24D5)"
              fillRule="evenodd"
              id="Vector"
            />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Section01() {
  return (
    <div
      className="absolute h-[620px] left-0 top-[7029px] w-[1440px]"
      data-name="Section 01"
    >
      <div className="absolute flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] left-[254px] not-italic text-[#202939] text-[16px] text-left text-nowrap top-[66px] translate-y-[-50%]">
        <p className="block leading-[24px] whitespace-pre">Pages</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[254px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[113.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Home v1</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[254px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[150.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Home v2</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[254px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[187.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Home v3</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[254px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[224.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Company v1</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[254px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[261.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Company v2</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[254px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[298.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Company v3</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[254px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[335.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Other templates</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] left-[429px] not-italic text-[16px] text-left text-nowrap top-[66px] translate-y-[-50%]">
        <p className="block leading-[24px] whitespace-pre">Pages</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[429px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[113.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Blog v1</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[429px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[150.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Blog v2</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[429px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[187.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Blog v3</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[429px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[224.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Contact</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[429px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[261.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Careers</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] left-[603px] not-italic text-[#202939] text-[16px] text-left text-nowrap top-[66px] translate-y-[-50%]">
        <p className="block leading-[24px] whitespace-pre">CMS Pages</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[603px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[113.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Blog Post</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[603px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[150.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Blog Categories</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[603px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[187.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Team Members</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[603px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[224.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">
          Pricing Categories
        </p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[603px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[261.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Pricing Single</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[603px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[298.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Careers Single</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] left-[778px] not-italic text-[#202939] text-[16px] text-left text-nowrap top-[66px] translate-y-[-50%]">
        <p className="block leading-[24px] whitespace-pre">Utility Pages</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[778px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[113.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Style Guide</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[778px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[150.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Licenses</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[778px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[187.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Changelog</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[778px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[224.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">404</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[778px] not-italic text-[#697586] text-[14px] text-left text-nowrap top-[261.5px] translate-y-[-50%]">
        <p className="block leading-[21px] whitespace-pre">Password</p>
      </div>
      <div
        className="absolute inset-[9.19%_92.57%_86.45%_5.56%]"
        data-name="Vector"
      >
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 27 27"
        >
          <path
            d={svgPaths.p19cc8df0}
            fill="var(--fill-0, #BA24D5)"
            id="Vector"
          />
        </svg>
      </div>
      <div
        className="absolute inset-[10%_85.21%_87.26%_8.33%]"
        data-name="Vector"
      >
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 93 17"
        >
          <path
            d={svgPaths.p34aaf980}
            fill="var(--fill-0, #202939)"
            id="Vector"
          />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Poppins:SemiBold',_sans-serif] justify-center leading-[0] left-[944px] not-italic text-[#202939] text-[16px] text-left text-nowrap top-[69px] translate-y-[-50%]">
        <p className="block leading-[24px] whitespace-pre">Subscribe</p>
      </div>
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[24px] left-[944px] not-italic text-[#697586] text-[16px] text-left text-nowrap top-[122px] translate-y-[-50%] whitespace-pre">
        <p className="block mb-0">
          Join our newsletter to stay up to date on features
        </p>
        <p className="block">and releases.</p>
      </div>
      <Frame1618872606 />
      <Frame1618872612 />
      <div className="absolute flex flex-col font-['Poppins:Regular',_sans-serif] justify-center leading-[0] left-[944px] not-italic text-[#697586] text-[0px] text-left top-[252px] translate-y-[-50%] w-[416px]">
        <p className="leading-[18px] text-[12px]">
          <span>{`By subscribing you agree to with our `}</span>
          <span className="[text-decoration-line:underline] [text-decoration-skip-ink:none] [text-decoration-style:solid] [text-underline-position:from-font] font-['Poppins:Regular',_sans-serif] not-italic text-[#697586]">
            Privacy Policy
          </span>
          <span>{` and provide consent to receive updates from our company.`}</span>
        </p>
      </div>
      <div
        className="absolute bg-[#eef2f6] h-px left-20 top-[459px] w-[1280px]"
        data-name="div.line-divider"
      />
      <Frame1618872581 />
      <Group1321314448 />
      <Group1321314449 />
      <Group1321314450 />
      <Group1321314451 />
    </div>
  );
}

export default function LandingPage() {
  return (
    <div className="bg-[#ffffff] relative size-full" data-name="Landing page">
      <Section10 />
      <Section09 />
      <Section08 />
      <Section07 />
      <Section06 />
      <Section05 />
      <Section04 />
      <Section03 />
      <Section02 />
      <Section01 />
    </div>
  );
}