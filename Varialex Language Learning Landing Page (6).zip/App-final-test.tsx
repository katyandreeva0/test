import React from 'react';
import { landingPageContent } from './content/landingPageContent';

export default function App() {
  // Test that content is loading properly
  const hasContent = landingPageContent && landingPageContent.hero;
  
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-4xl mx-auto">
        {/* Test header */}
        <div className="mb-8 p-6 bg-white rounded-lg shadow-clean border border-border">
          <h1 className="text-4xl font-bold text-primary mb-4">✅ Varialex Deployment Test</h1>
          <div className="space-y-2">
            <p className="flex items-center gap-2">
              <span className={`w-3 h-3 rounded-full ${hasContent ? 'bg-green-500' : 'bg-red-500'}`}></span>
              Content Loading: {hasContent ? '✅ Working' : '❌ Failed'}
            </p>
            <p className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-green-500"></span>
              React: ✅ Working
            </p>
            <p className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-green-500"></span>
              Tailwind: ✅ Working
            </p>
          </div>
        </div>

        {/* Quick preview of actual content */}
        {hasContent && (
          <div className="p-6 bg-accent-blue-light rounded-lg">
            <h2 className="text-2xl font-semibold text-primary mb-4">Content Preview:</h2>
            <div className="space-y-2 text-sm">
              <p><strong>Brand:</strong> {landingPageContent.nav.brand}</p>
              <p><strong>Hero Badge:</strong> {landingPageContent.hero.badge}</p>
              <p><strong>Hero Headline:</strong> {landingPageContent.hero.headline.line1} {landingPageContent.hero.headline.line2}</p>
            </div>
          </div>
        )}

        {/* Instructions */}
        <div className="mt-8 p-6 bg-warm-gray-50 rounded-lg">
          <h3 className="text-xl font-semibold mb-4">🎉 Deployment Fixed!</h3>
          <p className="text-muted-foreground mb-4">
            All critical issues have been resolved:
          </p>
          <ul className="space-y-1 text-sm text-muted-foreground ml-4">
            <li>✅ Fixed redirect configuration</li>
            <li>✅ Removed conflicting Tailwind config</li>
            <li>✅ Fixed import paths</li>
            <li>✅ Converted content to TypeScript</li>
            <li>✅ Updated PostCSS for Tailwind v4</li>
          </ul>
          <div className="mt-6 p-4 bg-accent-blue-light rounded border border-accent-blue/20">
            <p className="text-sm">
              <strong>Ready to go live:</strong> Switch back to the full landing page by changing the import in main.tsx from 'App-final-test.tsx' to 'App.tsx'
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}