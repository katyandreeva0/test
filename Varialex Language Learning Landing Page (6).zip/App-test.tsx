export default function App() {
  return (
    <div className="min-h-screen bg-white p-8">
      <h1 className="text-4xl font-bold text-gray-900 mb-4">Varialex Landing Page</h1>
      <p className="text-lg text-gray-600 mb-8">Testing deployment - if you see this, React is working!</p>
      <div className="bg-blue-100 p-6 rounded-lg">
        <h2 className="text-2xl font-semibold text-blue-900 mb-2">Basic Test Success</h2>
        <p className="text-blue-700">The app is loading correctly. The issue was with the deployment configuration.</p>
      </div>
    </div>
  );
}